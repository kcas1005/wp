package com.example.demo.controller;

import com.example.demo.domain.account_info.Member;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataAPIController {
//
//    @GetMapping("api/read/{id}")
//    @ResponseBody
//    public Member memberInfo(@PathVariable String id) {
//        System.out.println(id);
////        Member member = new Member();
//
//        return member;
//    }
}
