//package com.example.demo;
//
//import com.example.demo.domain.Board;
//import com.example.demo.persistence.BoardRepository;
//import org.junit.Before;
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.util.List;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//class DemoApplicationTests {
////
////    @Autowired
////    private BoardRepository boardRepo;
////
////    @Before
////    public void dataPrepare() {
////        for (int i = 1; i <= 200; i++) {
////            Board board = Board.builder()
////                    .title("테스트 제목 " + i)
////                    .writer("테스터")
////                    .content("테스트 내용 " + i)
////                    .build();
////
////            boardRepo.save(board);
////        }
////    }
//
////     @Test
////     public void testInsertBoard() {
////         Board board = Board.builder()
////                         .title("테이블 제목")
////                         .writer("Rubisco")
////                         .content("첫번째 글입니다.")
////                         .build();
////
////         boardRepo.save(board);
////     }
//
////    @Test
////    public void testFindByTitle() {
////        List<Board> boardList = boardRepo.findByTitle("테스트 제목 10");
////
////        System.out.println("검색 결과");
////        for (Board board : boardList) {
////            System.out.println("---> " + board.toString());
////        }
////    }
//
//}
