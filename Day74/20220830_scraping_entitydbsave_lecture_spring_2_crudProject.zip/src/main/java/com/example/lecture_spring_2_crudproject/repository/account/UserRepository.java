//package com.example.lecture_spring_2_crudproject.repository.account;
//
//import com.example.lecture_spring_2_crudproject.entity.account.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface UserRepository extends JpaRepository<User, Long> {
//}
