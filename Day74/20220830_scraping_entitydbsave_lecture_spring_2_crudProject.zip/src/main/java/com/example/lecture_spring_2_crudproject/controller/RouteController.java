package com.example.lecture_spring_2_crudproject.controller;

public class RouteController {
}
