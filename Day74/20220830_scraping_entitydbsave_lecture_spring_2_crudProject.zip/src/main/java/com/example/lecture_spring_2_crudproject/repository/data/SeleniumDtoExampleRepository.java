package com.example.lecture_spring_2_crudproject.repository.data;

import com.example.lecture_spring_2_crudproject.entity.data.SeleniumDtoExample;
import org.springframework.data.repository.CrudRepository;

public interface SeleniumDtoExampleRepository extends CrudRepository<SeleniumDtoExample, Long> {
}
