//package com.example.lecture_spring_2_crudproject.repository.account;
//
//import com.example.lecture_spring_2_crudproject.entity.account.Team;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface TeamRepository extends JpaRepository<Team, Long> {
//}
