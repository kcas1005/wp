package com.example.lecture_spring_2_crudproject.repository.data;

import com.example.lecture_spring_2_crudproject.entity.data.ScrapingEntity;
import org.springframework.data.repository.CrudRepository;

public interface ScrapingEntityRepository extends CrudRepository<ScrapingEntity, Long> {
}
