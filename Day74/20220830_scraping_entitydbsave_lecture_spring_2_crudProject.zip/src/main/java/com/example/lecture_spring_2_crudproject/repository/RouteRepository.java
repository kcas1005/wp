package com.example.lecture_spring_2_crudproject.repository;

public class RouteRepository {
}
