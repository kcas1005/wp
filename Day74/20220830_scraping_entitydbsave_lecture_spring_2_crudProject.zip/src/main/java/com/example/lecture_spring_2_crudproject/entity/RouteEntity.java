package com.example.lecture_spring_2_crudproject.entity;

public class RouteEntity {
}
