package com.example.lecture_spring_2_crudproject.entity.customDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomAPIDtoExample {

    private String title;
    private String content;
}
