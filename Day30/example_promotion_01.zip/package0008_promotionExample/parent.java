package package0008_promotionExample;

public class parent {

    public void method1() {
		System.out.println("Parent-method1()");
	}
	
	public void method2() {
		System.out.println("Parent-method2()");
	}
    
}
