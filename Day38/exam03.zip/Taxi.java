package Day38.exam03;

public class Taxi implements Vehicle {
	@Override
	public void run() {
		System.out.println("택시가 달린다. ");
	}
	public void checkFare(){
		System.out.println("택시 요금이 얼마나 내었나요?");
	}
}