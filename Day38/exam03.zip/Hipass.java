package Day38.exam03;

public interface Hipass{
    void enter();
    void exit();

}
