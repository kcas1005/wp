package Day38.exam03;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
	public void driveCheck(Vehicle vehicle){
		if(vehicle instanceof Bus){
			Bus bus = (Bus) vehicle;
			bus.checkFare();
		}
		else if(vehicle instanceof Taxi){
			Taxi texi = (Taxi) vehicle;
			texi.checkFare();
		}
	}
}