package Day38.exam03;

public class Bus implements Vehicle , Pay {
	@Override
	public void run() {
		System.out.println("버스가 달린다. ");
	}
	public void checkFare(){
		System.out.println("얼마나 내었나요?");
	}
	public void pay();
}