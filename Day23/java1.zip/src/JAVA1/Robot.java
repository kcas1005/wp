package JAVA1;

public class Robot {
    int RobotNum = 2;
    String RobotName = "mazingga";
    String Color = "red";
    int speed = 350;
}
