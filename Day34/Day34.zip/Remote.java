public interface Remote {

    public int favorite = 0;
    
    void tv_remote(int input_channel);
    
}
