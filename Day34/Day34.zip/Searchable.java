public interface Searchable {
	void search(String url);
	void Channel(int input_channel);
}
