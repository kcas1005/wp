//package com.example.initproject.domain;
//
//import javax.persistence.*;
//
//@Entity
//@Table(name="customers")
//public class User {
//
//    @Id
//    @Column(name = "customer_id")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private String name;
//    private String email;
//}
