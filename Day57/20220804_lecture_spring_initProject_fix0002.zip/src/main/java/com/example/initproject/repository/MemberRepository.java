//package com.example.initproject.repository;
//
//import com.example.initproject.domain.Member;
//
//import java.util.List;
//import java.util.Optional;
//
//public interface MemberRepository {
//    //optional java8부터 쓰이는 null처리 객체
//    Member save(Member member);
//    Optional<Member> findById(Long id);
//    Optional<Member> findByName(String name);
//    List<Member> findAll();
//}
