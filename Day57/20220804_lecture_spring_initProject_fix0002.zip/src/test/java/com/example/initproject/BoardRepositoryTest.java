package com.example.initproject;

import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class BoardRepositoryTest {
}
