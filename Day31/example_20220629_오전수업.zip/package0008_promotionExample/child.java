package package0008_promotionExample;

public class child extends parent {

    @Override
	public void method2() {
		System.out.println("Child-method2()");
	}
	
	public void method3() {
		System.out.println("Child-method3()");
	}
    
}
