package package0004_gameSlimeLand.inven.armor;

public class TypeA {
    
    public int MaxDurabilty;
    public int durabilty;

}
