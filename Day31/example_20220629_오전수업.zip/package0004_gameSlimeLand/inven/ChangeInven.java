package package0004_gameSlimeLand.inven;

public class ChangeInven {

    public static void ChangeInven() {
        
    }
    
}
