package package0004_gameSlimeLand.slime;

public class actionSlime {

    public void playAction() {
        System.out.println("슬라임이 이동합니다");
    }
    
}
