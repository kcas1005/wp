package package0004_gameSlimeLand.object;

public class DistanceParentClass {
    
}
