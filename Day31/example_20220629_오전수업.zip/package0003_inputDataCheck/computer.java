package package0003_inputDataCheck;

public class computer {

    public String name;
    public String cpu;
    public String ram;
    public String ssd;

    public computer(String name, String cpu, String ram, String ssd) {
        this.name = name;
        this.cpu = cpu;
        this.ram = ram;
        this.ssd = ssd;

    }
    
}
