package package0005_invenItemOverridingExample;

public class WeaponShot001 extends WeaponMethod {
    
    WeaponShot001() {
        this.name = "숏소드";
        this.AttRange = 2;
        this.ChangeTime = 3;
    }

}
