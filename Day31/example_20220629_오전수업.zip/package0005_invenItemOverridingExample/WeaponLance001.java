package package0005_invenItemOverridingExample;

public class WeaponLance001 extends WeaponMethod {

    public WeaponLance001() {
        this.name = "랜스";
        this.AttRange = 2;
        this.ChangeTime = 3;
    }


}
