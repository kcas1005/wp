package package0005_invenItemOverridingExample;

public class WeaponLong001 extends WeaponMethod {

    public WeaponLong001() {
        this.name = "롱소드";
        this.AttRange = 2;
        this.ChangeTime = 3;
    }

  


}
