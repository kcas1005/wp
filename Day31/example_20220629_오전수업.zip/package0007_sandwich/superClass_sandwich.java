package package0007_sandwich;

public class superClass_sandwich {

    protected String name;
    protected String bread;
    protected String butter; 

    protected superClass_sandwich(String name ,String bread, String butter) {
        this.name = name;
        this.bread = bread;
        this.butter = butter;
    }
    
}
