package package0001_calc;

public class Calc {
    public static int calcTest(int input) {
        return input*2;
    }
}
