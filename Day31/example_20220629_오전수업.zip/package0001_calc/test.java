package package0001_calc;

public class test {
    int var1 = 10;
    int var2 = 012;
    int var3 = 0xA;

    public void output() {
        System.out.println(var1);
        System.out.println(var2);
        System.out.println(var3);
    }
}
