package com.mysite.sbb.user;
import javax.persistence.*;

import lombok.*;

@Getter
@Setter
@Entity
@Data
@NoArgsConstructor
public class SiteUser {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(unique = true)
    private String username;

    private String password;

    @Column(unique = true)
    private String email;

    @Column(unique = true)
    private String nickname;

    private String role;

    @PrePersist
    public void setting() {
        this.role = "ROLE_USER";
    }

    private String profileImage;



    private String ImageName;


}