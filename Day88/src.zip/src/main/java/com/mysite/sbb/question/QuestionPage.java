package com.mysite.sbb.question;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class QuestionPage {
    @Id
    private Integer id;
    private String PREVID;
    private String PREV_SUBJECT;
    private String NEXTID;
    private String NEXT_SUBJECT;
}
