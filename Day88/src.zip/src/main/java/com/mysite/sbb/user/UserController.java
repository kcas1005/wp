package com.mysite.sbb.user;

import javax.annotation.Nullable;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.mysite.sbb.question.Question;
import com.mysite.sbb.question.QuestionForm;
import org.openqa.selenium.devtools.v85.profiler.model.Profile;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;


import lombok.RequiredArgsConstructor;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.Optional;

@RequiredArgsConstructor
@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;


    @GetMapping("/signup")
    public String signup(UserCreateForm userCreateForm) {
        return "signup_form";
    }

    @PostMapping("/signup")
    public String signup(@Valid UserCreateForm userCreateForm, BindingResult bindingResult, MultipartFile file) {
        if (bindingResult.hasErrors()) {
            return "signup_form";
        }

        if (!userCreateForm.getPassword1().equals(userCreateForm.getPassword2())) {
            bindingResult.rejectValue("password2", "passwordInCorrect",
                    "2개의 패스워드가 일치하지 않습니다.");
            return "signup_form";
        }
        try {
        userService.create(userCreateForm.getUsername(),
                userCreateForm.getEmail(), userCreateForm.getPassword1(), userCreateForm.getNickname(),file);
        }catch(DataIntegrityViolationException e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", "이미 등록된 사용자입니다.");
            return "signup_form";
        }catch(Exception e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", e.getMessage());
            return "signup_form";
        }

        return "redirect:/";
    }

    @GetMapping("/login")
    public String login() {
        return "login_form";
    }


//    프로필 하는중
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/user_info")
    public String viewProfile(UserUpdateForm userUpdateForm, Model model, Principal principal){
        SiteUser siteUser = this.userService.getUser(principal.getName());
        model.addAttribute("siteUser",siteUser);
        return "user_info";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/user_info")
    public String usermodify(UserUpdateForm userUpdateForm, Principal principal, @RequestParam(value = "file", required = false)MultipartFile file) throws Exception {
        SiteUser siteUser = this.userService.getUser(principal.getName());
        this.userService.modify(siteUser, userUpdateForm.getNickname(), file);

        return "redirect:/user/user_info";
    }




}