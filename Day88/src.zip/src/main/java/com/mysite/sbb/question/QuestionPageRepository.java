package com.mysite.sbb.question;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface QuestionPageRepository extends JpaRepository<QuestionPage, Integer> {

    @Query(value = "SELECT * FROM (SELECT ID,"+
            " LAG(ID,1,0) OVER(ORDER BY ID ASC) PREVID, "+
            " LAG(SUBJECT,1,'이전글이 없습니다.') OVER(ORDER BY ID ASC) PREV_SUBJECT,"+
            " LEAD(ID,1,0) OVER(ORDER BY ID ASC) NEXTID, "+
            " LEAD(SUBJECT,1,'다음글이 없습니다.') OVER(ORDER BY ID ASC) NEXT_SUBJECT "+
            " FROM Question) WHERE ID = :id",
            nativeQuery = true)
    QuestionPage findByPages(Integer id);
}
