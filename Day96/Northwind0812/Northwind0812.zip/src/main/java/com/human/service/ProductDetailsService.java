package com.human.service;


import com.human.domain.ProductDto;

public interface ProductDetailsService {
	
	public ProductDto getList(int productId);
	
	
	
}
