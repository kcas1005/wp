package com.human.mapper;


import com.human.domain.ProductDto;

public interface ProductDetailsMapper {
	
	public ProductDto getList(int productId);
	

	
}
