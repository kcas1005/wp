function Check(){
	var myForm=document.getElementById('myForm');
	myForm.submit();
}
