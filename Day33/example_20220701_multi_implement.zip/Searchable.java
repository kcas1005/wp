package sec03.exam03_multi_implement_class;

public interface Searchable {
	void search(String url);
}
