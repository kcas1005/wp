package com.example.lecture_spring_2_crudproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LectureSpring2CrudProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
