
public class Sandwich{
    int day;
    String bread;
    String butter;
    
    
    public void Sandwich(String bread, String butter, String c){
        this.bread = bread;
        System.out.println(this.bread +" 을 넣습니다");
        this.butter = butter;
        System.out.println(this.butter +" 를 넣습니다");
        
    }
    public void Sandwich(String bread, String butter, String c, String d){
        this.bread = bread;
        System.out.println(this.bread +" 을 넣습니다");
        this.butter = butter;
        System.out.println(this.butter +" 를 넣습니다");
    }
    public static void weekTest(int day){
        switch(day){

            case 1:
                
            case 2:

            case 3:

            case 4:

            case 5:
        }
    }
    public void eat(){

    }
}