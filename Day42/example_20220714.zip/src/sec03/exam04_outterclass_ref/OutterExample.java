package sec03.exam04_outterclass_ref;

public class OutterExample {
	public static void main(String[] args) {
		Outter outter = new Outter();
		Outter.Nested nested = outter.new Nested();
		nested.print();

		Outter A1 = new Outter();
		Outter A2 = new Outter();

		A1.a = 10;
		A2.a = 20;
		System.out.println(A1.a);
	}
}
