package sec03.exam04_outterclass_ref;

public class Outter {
	String field = "Outter-field";
	static int a = 10;
	void method() {
		System.out.println("Outter-method");
	}
	
	class Nested {
		String field = "Nested-field";
		void method() {
			System.out.println("Nested-method");
		}
		void print() {
			System.out.println("ù ��° this.field : "+this.field);
			System.out.println("�� ��° this.method() ����");
			this.method();
			System.out.println("�� ��° Outter.this.field : "+Outter.this.field);
			System.out.println("�� ��° Outter.this.method() ����");
			Outter.this.method();
		}
	}
}
