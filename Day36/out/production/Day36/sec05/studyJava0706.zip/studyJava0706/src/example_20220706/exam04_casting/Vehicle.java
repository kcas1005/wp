package example_20220706.exam04_casting;

public interface Vehicle {
	public void run();
}
