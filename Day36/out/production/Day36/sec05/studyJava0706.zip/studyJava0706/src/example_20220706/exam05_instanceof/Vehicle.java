package example_20220706.exam05_instanceof;

public interface Vehicle {
	public void run();
}
