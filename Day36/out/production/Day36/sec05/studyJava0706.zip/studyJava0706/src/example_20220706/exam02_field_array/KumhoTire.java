package example_20220706.exam02_field_array;

public class KumhoTire implements Tire {
	@Override
	public void roll() {
		System.out.println(" ");
	}
}
