package example_20220706.exam05_instanceof;

public class Bus implements Vehicle {
	@Override
	public void run() {
		System.out.println(" ");
	}
	
	public void checkFare() {
		System.out.println(" ");
	}
}
