package exam05_instanceof;

public interface Vehicle {
	public void run();
}
