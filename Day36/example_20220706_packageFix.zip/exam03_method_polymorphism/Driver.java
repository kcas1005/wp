package exam03_method_polymorphism;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
