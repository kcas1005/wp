package exam04_casting;

public interface Vehicle {
	public void run();
}
