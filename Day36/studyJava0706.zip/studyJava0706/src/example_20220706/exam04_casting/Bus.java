package example_20220706.exam04_casting;

public class Bus implements Vehicle {
	@Override
	public void run() {
		System.out.println(" ");
	}
	
	public void checkFare() {
		System.out.println(" ");
	}
}
