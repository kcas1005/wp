package example_20220706.exam03_method_polymorphism;

public interface Vehicle {
	public void run();
}
