package example_20220706.exam01_field_polymorphism;

public interface Tire {
	
	//자식 클래스에서 반드시 구현되어야 하는 추상메소드
	public void roll();
	
	
}
