package example_20220706.exam01_field_polymorphism;

public interface Brake {
    public void stop();
}
