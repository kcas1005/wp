package example_20220706.Fruit;

import java.io.IOException;

public class Fruit_M {
    public static void main(String[] args) throws IOException {
        Fruit_E fruit_es = new Fruit_E();

        fruit_es.eat_H();


//        Fruit fruit_e = null;
//        Fruit fruit_G = new Grape();
//        Fruit fruit_P = new Peach();
//        Fruit fruit_M = new Mango();
//
//        Grape grape = (Grape) fruit_G;
//        Peach peach = (Peach) fruit_P;
//        Mango mango = (Mango) fruit_M;
//
//        int ch = System.in.read();
//        if (ch == 'G' || ch == 'g') {
//            fruit_e = new Grape();
//           // grape.Pick(fruit_G);
//        } else if (ch == 'P' || ch == 'p') {
//            fruit_e = new Peach();
//           // peach.Pick(fruit_P);
//        } else if (ch == 'M' || ch == 'm') {
//            fruit_e = new Mango();
//           // mango.Pick(fruit_M);
//        } else {
//            System.out.println("다시 입력해주세요.");
//            return;
//        }
//        fruit_e.Fruits();
    }


}
