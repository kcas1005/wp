package example_20220706.Fruit;

import example_20220706.exam01_field_polymorphism.newHankookTire;

public interface Fruit {


    public void Fruits();
    public void eat(String name);



}
