package sec05.exam05_instanceof;

public class Taxi implements Vehicle {
	@Override
	public void run() {
		System.out.println(" ");
	}
}
