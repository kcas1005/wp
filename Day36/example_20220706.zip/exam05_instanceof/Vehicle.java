package sec05.exam05_instanceof;

public interface Vehicle {
	public void run();
}
