package sec05.exam02_field_array;

public class HankookTire implements Tire {
	@Override
	public void roll() {
		System.out.println(" ");
	}
}
