package sec05.exam01_field_polymorphism;

public interface Tire {
	public void roll();
}
