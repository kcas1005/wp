package sec05.exam04_casting;

public interface Vehicle {
	public void run();
}
