package ExceptionExam;

public class MaxException extends Exception{
    public MaxException(String message) {
        super(message);
    }
}
