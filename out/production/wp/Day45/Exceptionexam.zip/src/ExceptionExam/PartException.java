package ExceptionExam;

public class PartException extends Exception {

    public PartException(String message) {
        super(message);
    }
}
