package ExceptionExam;

public class NewTeamPeopleException extends Exception{
    public NewTeamPeopleException(String message) {
        super(message);
    }
}

