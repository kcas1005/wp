package ExceptionExam1;

public class TeamPeople {
    String part;
    String name;

    public TeamPeople(String name) {
        name =this.name;
    }



}
