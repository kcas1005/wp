package Day39.exam03;

public interface People{

}
