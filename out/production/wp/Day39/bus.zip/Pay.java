package Day39.exam03;

public interface Pay {
    void pay();
}
