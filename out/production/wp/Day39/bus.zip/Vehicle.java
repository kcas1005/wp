package Day39.exam03;

public interface Vehicle {

	void run();
	void runaway();
	void checkFare();
}